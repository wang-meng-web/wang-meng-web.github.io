---
title: '2023 Maker Faire Roma! And my stand!'
date: 2023-10-20
permalink: /posts/2012/08/blog-post-4/

---

<div style="text-align: center;">
   <img width="400" src='/images/my_stand.png'>
   <img width="430" src='/images/maker_faire.png'>
</div>

<!--This post will show up by default. To disable scheduling of future posts, edit `config.yml` and set `future: false`. -->
