---
title: "Stress Monitoring of Plates by Means of Nonlinear Guided Waves"
collection: publications
permalink: /publication/2009-10-01-paper-title-number-1
excerpt: '**Meng Wang**, Annamaria Pau'
date: 2022-06-01
venue: 'In book: European Workshop on Structural Health Monitoring, EWSHM 2022 - Volume 3 (pp.212-220)'
paperurl: 'http://miogattograsso.github.io/files/533636_1_En_22_Chapter_Author.pdf'
citation: 'Wang, M., Pau, A. Stress Monitoring of Plates by Means of Nonlinear Guided Waves, European Workshop on Structural Health Monitoring 2022, Volume 3, pp.212-220'
---

[Download paper here](http://miogattograsso.github.io/files/533636_1_En_22_Chapter_Author.pdf)

Recommended citation: Wang, M., Pau, A. Stress Monitoring of Plates by Means of Nonlinear Guided Waves, European Workshop on Structural Health Monitoring 2022, Volume 3, pp.212-220
