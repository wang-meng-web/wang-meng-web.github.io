---
title: "Design of mechanical metamaterials based on biphasic periodic microstructures"
collection: publications
permalink: /publication/2015-10-01-paper-title-number-3
excerpt: '**Meng Wang**, Annamaria Pau, Marco Lepidi.'
date: 2023-07-01
venue: ' X ECCOMAS Thematic Conference on Smart Structures and Materials 2023, Patras, Greece'
paperurl: 'http://miogattograsso.github.io/files/Wang_design_2023.pdf'
citation: 'Wang. M., Pau, A., Lepidi, M. Design of mechanical metamaterials based on biphasic periodic microstructures,  X ECCOMAS Thematic Conference on Smart Structures and Materials 2023'
---

[Download paper here](http://miogattograsso.github.io/files/Wang_design_2023.pdf)

Recommended citation: Wang. M., Pau, A., Lepidi, M. Design of mechanical metamaterials based on biphasic periodic microstructures,  X ECCOMAS Thematic Conference on Smart Structures and Materials 2023
