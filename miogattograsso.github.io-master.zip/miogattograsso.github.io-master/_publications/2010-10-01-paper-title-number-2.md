---
title: "Monitoring prestress in plates by sideband peak count-index (SPC-I) and nonlinear higher harmonics techniques"
collection: publications
permalink: /publication/2010-10-01-paper-title-number-2
excerpt: '**Meng Wang**, Annamaria Pau, Guangdong Zhang, Tribikram Kundu.'
date: 2023-03-01
venue: 'Nonlinear Dynamics'
paperurl: 'http://miogattograsso.github.io/files/Nonlinear_Dyn_final_version_compressed.pdf'
citation: 'Wang, M., Pau, A., Zhang, G., Kundu, T. Monitoring prestress in plates by sideband peak count-index (SPC-I) and nonlinear higher harmonics techniques, Nonlinear Dynamics, 111(17):1-18'
---

[Download paper here](http://miogattograsso.github.io/files/Nonlinear_Dyn_final_version_compressed.pdf)

Recommended citation: Wang, M., Pau, A., Zhang, G., Kundu, T. Monitoring prestress in plates by sideband peak count-index (SPC-I) and nonlinear higher harmonics techniques, Nonlinear Dynamics, 111(17):1-18
